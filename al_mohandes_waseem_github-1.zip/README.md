# المهندس وسيم — نسخة GitHub
هذا المشروع مهيأ ليُبنى عبر GitHub Actions من الهاتف.

## مهم
- Firebase project: engineer-waseem
- Android package: com.waseem.almohandes
- تم تضمين google-services.json.
- تسجيل Google مفعّل في الكود؛ يجب تفعيل Google Provider في Firebase.

## البناء
ارفع المجلد إلى مستودع GitHub خاص، ثم افتح Actions وشغّل Build Android APK.
الـAPK يظهر كـArtifact باسم `almohandes-waseem-apk`.

ملاحظة: هذه نسخة أولية. قبل التوزيع العام يجب إعداد توقيع release ثابت وإضافة SHA-1 الخاص به إلى Firebase.
