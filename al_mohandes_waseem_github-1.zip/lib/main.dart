
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'firebase_options.dart';
import 'package:google_sign_in/google_sign_in.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const WaseemApp());
}

class WaseemApp extends StatelessWidget {
  const WaseemApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'المهندس وسيم',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (snapshot.data == null) return const LoginPage();
        return const HomePage();
      },
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool loading = false;
  String? error;

  Future<void> signIn() async {
    setState(() { loading = true; error = null; });
    try {
      final googleUser = await GoogleSignIn().signIn();
      if (googleUser == null) {
        setState(() { loading = false; });
        return;
      }
      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      await FirebaseAuth.instance.signInWithCredential(credential);
    } catch (e) {
      setState(() { error = 'تعذر تسجيل الدخول. تأكد من إعداد Google في Firebase.'; });
    } finally {
      if (mounted) setState(() { loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.engineering, size: 90),
                const SizedBox(height: 18),
                const Text('المهندس وسيم',
                    style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                const Text('سجّل الدخول بحساب Google للمتابعة'),
                const SizedBox(height: 28),
                FilledButton.icon(
                  onPressed: loading ? null : signIn,
                  icon: const Icon(Icons.login),
                  label: Text(loading ? 'جاري الدخول...' : 'تسجيل الدخول بحساب Google'),
                ),
                if (error != null) ...[
                  const SizedBox(height: 16),
                  Text(error!, style: const TextStyle(color: Colors.red)),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  static const courses = [
    ('لغة عربية', 'باسم البابلي', 'إلكتروني'),
    ('كيمياء بيئية', 'عبد المجيد نصار', 'إلكتروني'),
    ('جيولوجيا هندسية', 'مازن أبو الطيف', 'وجاهي'),
    ('أساسيات الهندسة والبحث العلمي', 'خالد الحلاق', 'إلكتروني'),
    ('تفاضل وتكامل (أ) مناقشة', 'غير محدد', 'إلكتروني'),
    ('تفاضل وتكامل (أ)', 'بشر عقيلان', 'وجاهي'),
    ('فيزياء عامة (أ) مناقشة', 'غير محدد', 'إلكتروني'),
    ('فيزياء عامة عملية (أ)', 'غير محدد', 'إلكتروني'),
    ('فيزياء عامة (أ)', 'باسم السقا', 'وجاهي'),
    ('قرآن كريم (أ)', 'رأفت نصار', 'إلكتروني'),
  ];

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('المهندس وسيم'),
          actions: [
            IconButton(
              tooltip: 'تسجيل الخروج',
              onPressed: () => FirebaseAuth.instance.signOut(),
              icon: const Icon(Icons.logout),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: ListTile(
                leading: CircleAvatar(
                  child: Text((user?.displayName ?? 'و').characters.first),
                ),
                title: Text('أهلًا ${user?.displayName ?? ''}'),
                subtitle: Text(user?.email ?? ''),
              ),
            ),
            const SizedBox(height: 12),
            const Text('المواد', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            for (final c in courses)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.menu_book),
                  title: Text(c.$1),
                  subtitle: Text('${c.$2} • ${c.$3}'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => CoursePage(name: c.$1, instructor: c.$2, mode: c.$3),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class CoursePage extends StatelessWidget {
  final String name, instructor, mode;
  const CoursePage({super.key, required this.name, required this.instructor, required this.mode});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(name)),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            ListTile(title: const Text('المحاضر'), subtitle: Text(instructor)),
            ListTile(title: const Text('النمط'), subtitle: Text(mode)),
            const Divider(),
            const Text('المحاضرات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            for (int i = 1; i <= 12; i++)
              Card(
                child: ListTile(
                  leading: CircleAvatar(child: Text('$i')),
                  title: Text('محاضرة $i'),
                  subtitle: const Text('يمكن إضافة PDF أو رابط فيديو هنا'),
                  trailing: const Icon(Icons.play_circle_outline),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
