
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (defaultTargetPlatform == TargetPlatform.android) {
      return const FirebaseOptions(
        apiKey: 'AIzaSyCCdCkiXtC4GOIuugNg9gen8riSOgwNJRw',
        appId: '1:570127375783:android:de3331468dabe657382a82',
        messagingSenderId: '570127375783',
        projectId: 'engineer-waseem',
        storageBucket: 'engineer-waseem.firebasestorage.app',
      );
    }
    throw UnsupportedError('هذا الإصدار مجهز حاليًا لـ Android فقط.');
  }
}
